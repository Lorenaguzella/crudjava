# Demonstração de criação de um projeto em JAVA com acesso à uma base de dados MySQL
Neste repositório serão incluídas todas as etapas para a criação de um sistema de controle de Ordens de Serviço com sistema de login e verificação de nível de usuário logado dentro do sistema, além de prover acesso à emissão de relatórios das ordens de serviços geradas.

DER - DIAGRAMA ENTIDADE RELACIONAMENTO DA BASE DE DADOS
![image](https://user-images.githubusercontent.com/53703505/126907238-5e303c94-c537-4061-ad46-25a3a6d28c94.png)

Exemplo de inclusão de uma nova imagem no arquivo Readme.






Prof. Anderson Vanin - profandersonvanin@gmail.com
